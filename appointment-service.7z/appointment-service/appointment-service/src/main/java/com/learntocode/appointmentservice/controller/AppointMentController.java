package com.learntocode.appointmentservice.controller;

import com.learntocode.appointmentservice.dto.Appointment;
import com.learntocode.appointmentservice.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AppointMentController {
    
    @Autowired
    AppointmentService service;
    
    @PostMapping("/appointments")
    public ResponseEntity<Appointment> create(@RequestBody Appointment appointment)
    {
        Appointment appointmentRes = service.create(appointment);
        return ResponseEntity.accepted().body(appointmentRes);


    }
}
