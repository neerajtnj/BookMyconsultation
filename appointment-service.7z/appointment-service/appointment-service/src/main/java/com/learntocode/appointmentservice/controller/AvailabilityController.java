package com.learntocode.appointmentservice.controller;

import com.learntocode.appointmentservice.dto.Availability;
import com.learntocode.appointmentservice.service.AvailabilityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AvailabilityController {

    @Autowired
    AvailabilityService service;

    @PostMapping("/doctor/availability")
    public ResponseEntity<Availability> create(@RequestBody Availability availability)
    {
        Availability availabilityRes = service.create(availability);
        return ResponseEntity.accepted().body(availabilityRes);

    }
}