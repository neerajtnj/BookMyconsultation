package com.learntocode.appointmentservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Appointment {

    private String appointmentId;
    private Date appointmentDate;
    private Date createdDate;
    private String docId;
    private String priorMedicalHistory;
    private String status;
    private String symptom;
    private String timeSlot;
    private String userId;
    private String userEmailId;
    private String userName;
    private String doctorName;


}
