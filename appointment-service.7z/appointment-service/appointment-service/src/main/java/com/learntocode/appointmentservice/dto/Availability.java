package com.learntocode.appointmentservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.Date;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Availability {

    private BigInteger id;
    private String docId;
    private Date availabilityDate;
    private boolean isBooked;
    private String timeSlot;
}
