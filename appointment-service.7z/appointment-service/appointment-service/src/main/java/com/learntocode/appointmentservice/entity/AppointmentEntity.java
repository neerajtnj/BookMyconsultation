package com.learntocode.appointmentservice.entity;

import javax.persistence.*;
import java.util.Date;

@Entity(name="APPOINTMENT")
public class AppointmentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String appointmentId;
    @Column(name="appointment_date")
    private Date appointmentDate;
    @Column(name="created_date")
    private Date createdDate;
    @Column(name="doc_id")
    private String docId;
    @Column(name="prior_medical_history")
    private String priorMedicalHistory;
    @Column(name="status")
    private String status;
    @Column(name="symptom")
    private String symptom;
    @Column(name="time_slot")
    private String timeSlot;
    @Column(name="user_id")
    private String userId;
    @Column(name="user_Email_Id")
    private String userEmailId;
    @Column(name="user_name")
    private String userName;
    @Column(name="doctor_name")
    private String doctorName;
}
