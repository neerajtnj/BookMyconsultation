package com.learntocode.appointmentservice.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigInteger;
import java.util.Date;

@Entity(name = "AVAILABILITY")
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AvailabilityEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private BigInteger id;

    @Column(name = "doc_id")
    private String docId;
    @Column(name="availability_date")
    private Date availabilityDate;
    @Column(name="is_booked")
    private boolean isBooked;
    @Column(name="time_slot")
    private String timeSlot;
}
