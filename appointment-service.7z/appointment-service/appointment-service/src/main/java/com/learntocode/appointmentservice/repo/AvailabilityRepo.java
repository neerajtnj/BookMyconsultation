package com.learntocode.appointmentservice.repo;

import com.learntocode.appointmentservice.entity.AvailabilityEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;

@Repository
public interface AvailabilityRepo extends JpaRepository<AvailabilityEntity, BigInteger> {
}
