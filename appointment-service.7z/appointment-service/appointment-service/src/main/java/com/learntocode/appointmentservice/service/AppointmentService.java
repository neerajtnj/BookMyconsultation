package com.learntocode.appointmentservice.service;

import com.learntocode.appointmentservice.dto.Appointment;
import com.learntocode.appointmentservice.entity.AppointmentEntity;
import com.learntocode.appointmentservice.repo.AppointmentRepo;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AppointmentService {

    @Autowired
    AppointmentRepo repo;

    @Autowired
    ModelMapper mapper;

    public Appointment create(Appointment appointment)
    {
        AppointmentEntity entity = mapper.map(appointment, AppointmentEntity.class);
        Appointment appointmentRes = repo.save(appointment);
        return mapper.map(appointmentRes,Appointment.class);

    }

}
