package com.learntocode.appointmentservice.service;

import com.learntocode.appointmentservice.dto.Availability;
import com.learntocode.appointmentservice.entity.AvailabilityEntity;
import com.learntocode.appointmentservice.repo.AvailabilityRepo;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AvailabilityService {

    @Autowired
    AvailabilityRepo repo;

    @Autowired
    ModelMapper mapper;

    public Availability create(Availability availability)
    {
        AvailabilityEntity entity = mapper.map(availability, AvailabilityEntity.class);
        AvailabilityEntity availabilityEntity = repo.save(entity);
        return mapper.map(availabilityEntity,Availability.class);

    }
}
