package com.learntocode.doctorservice.controller;

import com.learntocode.doctorservice.dto.Doctor;
import com.learntocode.doctorservice.service.DoctorService;
import com.learntocode.doctorservice.util.S3util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController()
@RequestMapping("/api/v1")
public class DoctorController {

    @Autowired
    private DoctorService service;

    @Autowired
    private S3util s3util;

    @PostMapping(path = "/doctors",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Doctor> doctor(@RequestBody Doctor doc)
    {
        Doctor doctor = service.save(doc);
        return ResponseEntity.accepted().body(doctor);
    }

    @PostMapping("/doctors/{doctorId}/approve")
    public ResponseEntity<Doctor> approve(@RequestBody Doctor doc,@PathVariable String doctorId)
    {
        Doctor doctor = service.approve(doc,doctorId);
        return ResponseEntity.accepted().body(doctor);
    }

    @PostMapping("/doctors/{doctorId}/reject")
    public ResponseEntity<Doctor> reject(@RequestBody Doctor doc,@PathVariable String doctorId)
    {
        Doctor doctor = service.reject(doc,doctorId);
        return ResponseEntity.accepted().body(doctor);
    }

    @GetMapping("/doctors")
    public ResponseEntity<List<Doctor>> getDoctors(@RequestParam String status)
    {
        List<Doctor> doctorList = service.getDoctors(status);
        return ResponseEntity.ok(doctorList);

    }

    @PostMapping("/doctors/{doctorId}/document")
    public ResponseEntity<String> documents(@RequestBody List<MultipartFile> files
            , @PathVariable String doctorId )
    {
        files.stream().forEach(file->{

            try {
                s3util.uploadFiles(doctorId,file);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        return ResponseEntity.ok("File uploaded successfully");
    }
}
