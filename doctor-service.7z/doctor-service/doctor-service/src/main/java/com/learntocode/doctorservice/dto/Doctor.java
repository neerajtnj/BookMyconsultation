package com.learntocode.doctorservice.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.NumberFormat;

import javax.validation.constraints.*;
import java.util.Date;

@Data
@NoArgsConstructor
@JsonIgnoreProperties
@AllArgsConstructor
@Builder
public class Doctor {

    private String id;

    private String firstName;
    private String lastName;

    private String speciality;

    private String mobileNumber;
    private String emailId;

    private String pan;
    private String status;
    private String approvedBy;
    private String approverComments;
    private Date registrationDate;
    private Date verificationDate;

}
