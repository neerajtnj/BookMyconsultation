package com.learntocode.doctorservice.entity;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mongodb.lang.Nullable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.MongoId;

import java.util.Date;


@Document("Doctor")
@Builder
@Data
@JsonIgnoreProperties
@NoArgsConstructor
@AllArgsConstructor
public class DoctorEntity {

    @Id
    private String id;

    @Field
    private String firstName;
    @Field
    private String lastName;
    @Field
    @Nullable
    private String speciality;
    @Field
    @Nullable
    private String mobileNumber;
    @Field
    @Nullable
    private String emailId;
    @Field
    @Nullable
    private String pan;
    @Field
    private String status;
    @Field
    @Nullable
    private String approvedBy;
    @Nullable
    private String approverComments;
    @Nullable
    private Date registrationDate;
    @Field
    @Nullable
    private Date verificationDate;

}
