package com.learntocode.doctorservice.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.RestClientException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.List;
import java.util.stream.Collectors;

//@ControllerAdvice
public class DoctorControllerAdvice extends ResponseEntityExceptionHandler {

    @ExceptionHandler(RestClientException.class)
    public DoctorException handleException(RestClientException ex)
    {
       return  DoctorException.builder().errorCode("400").errorMessage("BAD_REUQEST")
                .build();
    }
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpHeaders headers,
            HttpStatus status, WebRequest request) {

        List<String> errors = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(x -> x.getDefaultMessage())
                .collect(Collectors.toList());

        DoctorException message = DoctorException.builder().fields(errors).errorCode("400")
                .errorMessage("BAD_REQUEST").build();
        return ResponseEntity.ok().body(message);
    }

}
