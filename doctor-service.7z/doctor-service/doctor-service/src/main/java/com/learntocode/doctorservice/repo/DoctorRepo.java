package com.learntocode.doctorservice.repo;

import com.learntocode.doctorservice.entity.DoctorEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DoctorRepo  extends MongoRepository<DoctorEntity,String> {

public Optional<List<DoctorEntity>> findByStatus(String status);
}
