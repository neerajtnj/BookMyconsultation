package com.learntocode.doctorservice.service;

import com.learntocode.doctorservice.dto.Doctor;
import com.learntocode.doctorservice.entity.DoctorEntity;
import com.learntocode.doctorservice.repo.DoctorRepo;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepo repo;

   @Autowired
   private ModelMapper mapper;

    public Doctor save(Doctor doc) {
        System.out.println("DOC {}"+doc);
        DoctorEntity entity = mapper.map(doc, DoctorEntity.class);
        System.out.println("DOC Entity {}"+entity);
        DoctorEntity doctorEntity = repo.save(entity);
        return mapper.map(doctorEntity, Doctor.class);
    }
    public Doctor approve(Doctor  doc,String docId) {
        Optional<DoctorEntity> doctor = repo.findById(docId);
        Doctor doctorDto= new Doctor();
        if(doctor.isPresent())
        {
            DoctorEntity doctorEntity = doctor.get();
            doctorEntity.setApprovedBy(doc.getApprovedBy());
            doctorEntity.setApproverComments(doc.getApproverComments());
            doctorEntity.setStatus("active");
            repo.save(doctorEntity);
            doctorDto=mapper.map(doctorEntity, Doctor.class);
        }
        return doctorDto;
    }
    public Doctor reject(Doctor  doc,String docId) {
        Optional<DoctorEntity> doctor = repo.findById(docId);
        Doctor doctorDto= new Doctor();
        if(doctor.isPresent())
        {
            DoctorEntity doctorEntity = doctor.get();
            doctorEntity.setApprovedBy(doc.getApprovedBy());
            doctorEntity.setApproverComments(doc.getApproverComments());
            doctorEntity.setStatus("reject");
            repo.save(doctorEntity);
            doctorDto=mapper.map(doctorEntity, Doctor.class);
        }
        return doctorDto;
    }

    public List<Doctor> getDoctors(String status )
    {
        List<DoctorEntity> doctorEntities = repo.findByStatus(status).orElse(Collections.emptyList());
        List<Doctor> docList= new ArrayList<>();
        doctorEntities.forEach(docEn->{
            Doctor doc= mapper.map(docEn,Doctor.class);
            docList.add(doc);
        });
        return docList;
    }
}

