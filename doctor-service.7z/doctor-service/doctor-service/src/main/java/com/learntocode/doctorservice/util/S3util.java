package com.learntocode.doctorservice.util;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.awscore.exception.AwsServiceException;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;

@Service
public class S3util {

    private AmazonS3 s3Client;
    private String BUCKET_NAME = "s3-upgrad-user-neeraj";// This needs to be a unique bucket name across all the regions.

    @Autowired
    ObjectMetadata metadata;

    @PostConstruct
    public void init(){
        String accessKey = "AKIASYYUSDOPDSOR32XM";
        String secretKey = "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";
        AWSCredentials credentials = new BasicAWSCredentials(accessKey,secretKey);
        s3Client = AmazonS3ClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withRegion(Regions.US_EAST_1)
                .build();
    }

    public void uploadFiles(String userId, MultipartFile file) throws IOException, IOException {
        String key = userId + "/"+ file.getOriginalFilename();
        if(!s3Client.doesBucketExistV2(BUCKET_NAME)){
            s3Client.createBucket(BUCKET_NAME);
        }
        s3Client.putObject(BUCKET_NAME,key,file.getInputStream(),metadata);
    }
}
