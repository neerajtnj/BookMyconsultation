package com.learntocode.userservice.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.MongoId;

@Document("User")
@Builder
@Data
@JsonIgnoreProperties
@NoArgsConstructor
@AllArgsConstructor
public class UserEntity {

    @MongoId
    private String id;

    private String firstName;
    private String lastName;

    private String mobileNumber;
    private String emailId;

    private String status;
}
