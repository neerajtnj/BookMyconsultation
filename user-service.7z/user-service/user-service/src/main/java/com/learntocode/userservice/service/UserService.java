package com.learntocode.userservice.service;

import com.learntocode.userservice.dto.User;
import com.learntocode.userservice.entity.UserEntity;
import com.learntocode.userservice.repo.UserRepo;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    UserRepo repo;

    @Autowired
    ModelMapper mapper;

    public User save(User user)
    {
        UserEntity userEntity = mapper.map(user, UserEntity.class);
        UserEntity entity = repo.save(userEntity);
        return mapper.map(entity,User.class);

    }

    public User getUser(String userId)
    {
        Optional<UserEntity> userEntity = repo.findById(userId);
        if(userEntity.isPresent())
        {
            return mapper.map(userEntity.get(),User.class);
        }
        return null;
    }

}
